EROS MUSIC - sitio estático

Subí index.html a la raíz de un repositorio y publicalo con GitHub Pages.
La página debe abrirse desde una URL HTTPS, no desde content:// ni file://.
No incluyas contraseñas, cookies, tokens ni datos privados.
